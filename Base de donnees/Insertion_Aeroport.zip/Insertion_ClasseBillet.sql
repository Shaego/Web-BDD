##INSERTION DES DONNÉES DANS LA TABLE ClasseBillet

USE BD_Aeroport_2018;

INSERT INTO tblClasseBillet VALUES
("CA","Classe affaires"),
("CP","Premiere classe"),
("CD","Deuxieme classe"),
("CE","Classe economique");