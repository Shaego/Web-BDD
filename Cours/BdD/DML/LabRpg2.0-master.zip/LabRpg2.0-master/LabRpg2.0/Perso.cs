﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Perso
    {
        private string nom;
        private string classe;
        private Armure armure;
        private Arme arme;
        private Bouclier bouclier;
        private Heaume heaume;
        private Item[] item;
        private int pv;

        public Perso(string nom, string classe)
        {
            this.nom = nom;
            this.classe = classe;
            item = new Item[3];
    
            pv = new Random().Next(7, 11);

        }


        public string GetInfoPersonnage()
        {            
            string info = "";

            info += ("Personnage {\n");
            info += ("     Nom    : " + nom + "\n");
            info += ("     Classe : " + classe + "\n");
            info += ("     Pv     : " + pv + "\n");

             if (arme == null)
            {
                info += ("Arme non équipée");
            }
             else
                info += ("     Arme   : " + arme.GetInfo());

            if (arme == null)
            {
                info += ("Armure non équipée");
            }
            else
                info += ("     Armure : " + armure.GetInfo() + "\n");

            if (arme == null)
            {
                info += ("Heaume non équipé");
            }
            else
                info += ("     Heaume : " + heaume.GetInfo() + "\n");

            if (arme == null)
            {
                info += ("Bouclier non équipé");
            }
            else
                info += ("     Bouclier : " + bouclier.GetInfo() + "\n");

            if (arme == null)
            {
                info += ("Item non équipé");
            }
            else
                info += ("     Equipement : " + item[0].GetInfo() + "\n");

            return info;
            
        }

        public void AjouterArmure(Armure armure)
        {
            this.armure = armure;
        }

        public void AjouterArme(Arme arme)
        {
            this.arme = arme;
        }

        public void AjouterBouclier(Bouclier bouclier)
        {
            this.bouclier = bouclier;
        }

        public void AjouterHeaume(Heaume heaume)
        {
            this.heaume = heaume;
        }

        public void AjouterEquipement(Item nouvelItem, int position)
        {
            item[position] = nouvelItem;
        }


    }

}
