﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Item
    {
        private string typeItem;
        private string desc;
        private int power;

        public Item(string typeItem, string desc, int power)
        {
            this.typeItem = typeItem;            
            this.desc = desc;            
            this.power = power;
            
        }

        public string GetInfo()
        {
            string info = "";

            info += (typeItem + " " + desc + " " + power + "\n");

            return info;
        }
       
    }
}
