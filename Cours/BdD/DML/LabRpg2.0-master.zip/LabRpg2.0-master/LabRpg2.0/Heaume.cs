﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Heaume
    {
        private int protection;
        private string typeHeaume;

        public Heaume(int protection, string typeHeaume)
        {
            this.protection = protection;
            this.typeHeaume = typeHeaume;

        }

        public string GetInfo()
        {
            string info = "";

            info += (protection + " " + typeHeaume + "\n");

            return info;
        }
    }
}
