﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class RPG
    {
        Perso perso;

        public RPG()
        {
            perso = null;
        }

        public void CreerPersonnage(string nom, string classe)
        {           
            perso = new Perso(nom, classe);
        }

        public string GetInfoPersonnage()
        {
            return perso.GetInfoPersonnage();
        }


        public void AjouterArmure(int lvl)
        {

            switch (lvl)
            {
                case 0:
                    perso.AjouterArmure(null);
                    break;
                case 1:
                    perso.AjouterArmure(new Armure(5, "Tunique des Milles Lames"));
                    break;
                case 2:
                    perso.AjouterArmure(new Armure(8, "Plastron Infaillible"));
                    break;
            }
        }

        public void AjouterArme(int lvl)
        {

            switch (lvl)
            {
                case 0:
                    perso.AjouterArme(null);
                    break;
                case 1:
                    perso.AjouterArme(new Arme(5, "Épée des cendres"));
                    break;
                case 2:
                    perso.AjouterArme(new Arme(8, "Hache de Gimli"));
                    break;
            }
        }
        public void AjouterBouclier(int lvl)
        {

            switch (lvl)
            {
                case 0:
                    perso.AjouterBouclier(null);
                    break;
                case 1:
                    perso.AjouterBouclier(new Bouclier(6, "Égide de Lunmière"));
                    break;
                case 2:
                    perso.AjouterBouclier(new Bouclier(9, "Barrière Célèste"));
                    break;
            }
        }

        public void AjouterHeaume(int lvl)
        {

            switch (lvl)
            {
                case 0:
                    perso.AjouterHeaume(null);
                    break;
                case 1:
                    perso.AjouterHeaume(new Heaume(4, "Capuchon du Seigneur de Guerre"));
                    break;
                case 2:
                    perso.AjouterHeaume(new Heaume(7, "Casque du Roi Néant"));
                    break;
            }
        }

        public void AjouterEquipement(string nom, string desc, int power, int position)
        {
            perso.AjouterEquipement(new Item(nom, desc, power), position);
        }
    }
}
