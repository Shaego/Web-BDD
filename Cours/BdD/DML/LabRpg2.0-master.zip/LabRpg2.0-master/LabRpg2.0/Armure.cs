﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Armure
    {
        private int protection;
        private string typeArmure;

        public Armure(int protection, string typeArmure)
        {
            this.protection = protection;
            this.typeArmure = typeArmure;

        }

        public string GetInfo()
        {
            string info = "";

            info += (protection + " " + typeArmure + "\n");

            return info;
        }
    }
}
