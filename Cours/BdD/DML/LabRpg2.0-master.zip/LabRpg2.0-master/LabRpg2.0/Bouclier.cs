﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Bouclier
    {
        private int protection;
        private string typeBouclier;

        public Bouclier(int protection, string typeBouclier)
        {
            this.protection = protection;
            this.typeBouclier = typeBouclier;

        }

        public string GetInfo()
        {
            string info = "";

            info += (protection + " " + typeBouclier + "\n");

            return info;
        }
    }
}
