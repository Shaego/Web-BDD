﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabRpg
{
    class Arme
    {
        private int dégat;
        private string typeArme;

        public Arme(int dégat, string typeArme)
        {
            this.dégat = dégat;
            this.typeArme = typeArme;

        }

        public string GetInfo()
        {
            string info = "";

            info += (dégat + " " + typeArme + "\n");

            return info;
        }
    }
}
